NEXA AI — Android PWA package preparation

Open this ZIP in your iPhone Files app to extract.
Upload the following 7 files TOGETHER to your NEXA-AI GitHub repository, main branch, at the top level (not inside a folder):
- index.html
- manifest.webmanifest
- sw.js
- apple-touch-icon.png
- icon-192.png
- icon-512.png
- icon-maskable-512.png

Commit changes, then inspect
https://nishantsheokand347-bit.github.io/NEXA-AI/manifest.webmanifest
After deployment, re-run https://www.pwabuilder.com on your NEXA AI URL.

AI capabilities still need internet and Puter sign-in; installing as APK does not remove service limits.
